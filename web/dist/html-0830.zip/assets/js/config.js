toastr.options.escapeHtml = true;
toastr.options.closeButton = true;
toastr.options.positionClass = 'toast-top-center';
toastr.options.preventDuplicates=true;
window.root='//www.xiaoyaoji.com.cn/api';
window.ctx='';
