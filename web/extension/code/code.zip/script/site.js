
var mf = chrome.runtime.getManifest();
//mark
document.body.setAttribute('data-ext-version',mf.version);